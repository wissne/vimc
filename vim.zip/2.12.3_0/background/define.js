"use strict";globalThis.__filename=null,(()=>{
let l={},e=l=>l.slice(l.lastIndexOf("/")+1).replace(".js",""),n=(l,e,n,u)=>{
n.bind(null,null,u).apply(null,e.slice(2).map(t))},t=n=>{n=e(n);let t=l[n];return t=t||(l[n]={}),t}
;globalThis.__moduleMap=l,globalThis.define=(t,u)=>{let s=e(__filename||document.currentScript.src)
;n(0,t,u,l[s]||(l[s]={}))}})();